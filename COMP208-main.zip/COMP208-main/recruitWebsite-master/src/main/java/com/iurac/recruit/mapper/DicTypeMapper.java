package com.iurac.recruit.mapper;

import com.iurac.recruit.entity.DicType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author iurac
 * @since 2021-06-03
 */
public interface DicTypeMapper extends BaseMapper<DicType> {

}
