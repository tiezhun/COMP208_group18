package com.iurac.recruit.exception;

public class ManageException extends Exception{

    public ManageException(String message) {
        super(message);
    }

}
