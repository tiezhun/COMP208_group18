package com.iurac.recruit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.iurac.recruit.entity.UserRole;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Entity com.iurac.recruit.domain.UserRole
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {

}




