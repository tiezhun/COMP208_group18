package com.iurac.recruit.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iurac.recruit.entity.ApplyResume;

public interface ApplyResumeService extends IService<ApplyResume> {
}